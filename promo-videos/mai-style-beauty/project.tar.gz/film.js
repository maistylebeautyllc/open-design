// Mai Style Beauty — 30 s vertical promo in the Art Deco style. Deterministic in t (seconds).
import * as D from './engine/deco.js';
import * as T from './engine/type.js';
import * as B from './engine/bulbs.js';
const { C, seg, ss, eio, eo, back, lerp, clamp, TAU } = D;

export const W = 1080, H = 1920, CX = W / 2, DUR = 30;
// ---------- editions (pick with ?ed=<key>) ----------
export const EDITIONS = {
  main: { accent: '#C8506A', jewel: '#1f5a4a', jewel2: '#3a1622', open: 'YOUR GLOW-UP', openSub: 'STARTS HERE', header: 'THE HOUSE OF MAI',
    close: 'BOOK YOUR APPOINTMENT', closeLine: 'YOUR GLOW-UP STARTS HERE', fx: null },
  thanksgiving: { accent: '#D2691E', jewel: '#4a2a10', jewel2: '#3b1d0c', open: 'HAPPY THANKSGIVING', openSub: 'GRATEFUL FOR YOU', header: 'THE HOUSE OF MAI',
    close: 'BOOK YOUR HOLIDAY GLAM', closeLine: 'THANKFUL FOR EVERY GLOW-UP', fx: 'leaves' },
  blackfriday: { accent: '#D2283C', jewel: '#1a1a1a', jewel2: '#3a0d12', open: 'BLACK FRIDAY', openSub: 'GLOW-UP WEEKEND', header: 'MAI STYLE BEAUTY',
    close: 'BLACK FRIDAY BOOKINGS OPEN', closeLine: 'TREAT YOURSELF THIS WEEKEND', fx: 'confetti' },
  hmong: { accent: '#C2187A', jewel: '#1c2a6b', jewel2: '#3a0f34', open: 'NYOB ZOO XYOO TSHIAB', openSub: 'HAPPY HMONG NEW YEAR', header: 'THE HOUSE OF MAI',
    close: 'BOOK YOUR NEW YEAR LOOK', closeLine: 'START THE NEW YEAR GLOWING', fx: 'coins' },
};
const ED = EDITIONS[(typeof location !== 'undefined' && new URLSearchParams(location.search).get('ed')) || 'main'] || EDITIONS.main;
const ROSE = ED.accent, EMER = ED.jewel, JEWEL2 = ED.jewel2;
const fitSize = (text, max, width, k) => Math.min(max, width / (text.length * k));

// holiday particles: falling leaves / gold confetti / silver coins, deterministic in t
function particles(g, t, a = 1) {
  if (!ED.fx || a <= 0) return;
  g.save(); g.globalAlpha *= a;
  for (let i = 0; i < 26; i++) {
    const h1 = D.hash(i * 1.7 + 3), h2 = D.hash(i * 3.3 + 1), h3 = D.hash(i * 5.1 + 7);
    const sp = 90 + h2 * 110, y = ((h1 * H + t * sp) % (H + 200)) - 100, x = 70 + h3 * (W - 140) + Math.sin(t * 1.3 + i) * 30;
    const rot = t * (h2 - .5) * 3 + i, sz = (ED.fx === 'leaves' ? 22 : 14) + h1 * 16;
    if (ED.fx === 'leaves') {
      const pts = []; for (let j = 0; j <= 16; j++) { const u = j / 16 * TAU; pts.push([x + Math.cos(rot) * Math.cos(u) * sz - Math.sin(rot) * Math.sin(u) * sz * .45 * Math.abs(Math.cos(u / 2)), y + Math.sin(rot) * Math.cos(u) * sz + Math.cos(rot) * Math.sin(u) * sz * .45 * Math.abs(Math.cos(u / 2))]); }
      D.drawShape(g, pts, { color: i % 3 ? ROSE : '#B8860B', lw: 1.2 });
    } else if (ED.fx === 'confetti') {
      D.sparkle(g, x, y, sz * .8, { rot, alpha: .5 + .5 * Math.sin(t * 4 + i), color: i % 4 ? C.goldHi : ROSE });
    } else if (ED.fx === 'coins') {
      const sx = Math.abs(Math.cos(rot)) * .9 + .1;
      g.save(); g.translate(x, y); g.scale(sx, 1);
      const gr = g.createRadialGradient(-sz * .3, -sz * .3, 0, 0, 0, sz); gr.addColorStop(0, '#ffffff'); gr.addColorStop(.5, '#c9ced6'); gr.addColorStop(1, '#6d7480');
      g.beginPath(); g.arc(0, 0, sz * .7, 0, TAU); g.fillStyle = gr; g.fill();
      g.beginPath(); g.arc(0, 0, sz * .5, 0, TAU); g.strokeStyle = 'rgba(80,86,96,.8)'; g.lineWidth = 1.5; g.stroke();
      g.restore();
    }
  }
  g.restore();
}

export const SERV_T0 = 4, SERV_LEN = 3.5;
export const SERVICES = [
  { title: 'HAIR STYLING', sub: 'CUTS · COLOR · BLOWOUTS', icon: 'scissors' },
  { title: 'HAIR EXTENSIONS', sub: 'LENGTH · VOLUME · FLOW', icon: 'strands' },
  { title: 'MAKEUP & SKIN', sub: 'GLAM · FACIALS · GLOW', icon: 'lipstick' },
  { title: 'TEETH WHITENING', sub: 'A BRIGHTER SMILE', icon: 'tooth' },
  { title: 'BODY SCULPTING', sub: 'CONTOUR · TONE · CONFIDENCE', icon: 'hourglass' },
];
export const BREATH = [21.5, 22.5];
export const MARQ_T0 = 22.5, MARQ_STEP = .25, CTA_T0 = 26;
// door boundaries: leaves close in [b-.4, b], open in [b, b+.5]
export const DOORS = [SERV_T0, ...SERVICES.map((_, i) => SERV_T0 + SERV_LEN * (i + 1))]; // 4 … 21.5

function bg(g, tint = null) {
  D.ground(g, W, H, { top: '#0f0b08', bot: C.ink, vig: 0 });
  if (tint) { const gr = g.createLinearGradient(0, H * .55, 0, H); gr.addColorStop(0, D.rgba(tint, 0)); gr.addColorStop(1, D.rgba(tint, .35)); g.fillStyle = gr; g.fillRect(0, 0, W, H); }
}
function frameBorder(g, a = 1) {
  g.save(); g.globalAlpha *= a;
  D.gline(g, D.rectPts(34, 34, W - 68, H - 68), { w: 2.2, closed: true, double: 9 });
  for (const [x, y, sx, sy] of [[34, 34, 1, 1], [W - 34, 34, -1, 1], [34, H - 34, 1, -1], [W - 34, H - 34, -1, -1]])
    D.fan(g, x, y, 46, { a0: sy > 0 ? (sx > 0 ? 0 : Math.PI / 2) : (sx > 0 ? -Math.PI / 2 : Math.PI), a1: sy > 0 ? (sx > 0 ? Math.PI / 2 : Math.PI) : (sx > 0 ? 0 : -Math.PI / 2), ribs: 5, fill: C.gold1 });
  g.restore();
}
function gem(g, x, y, r, t, { halo = 0 } = {}) {
  D.drawShape(g, D.starPts(x, y, r, .26, 0), { color: ROSE, halo, lw: 2 });
  D.sparkle(g, x + r * .1, y - r * .15, r * .5 * (.6 + .4 * Math.sin(t * 5)), { rot: t * .6 });
}

// ---------- icons (centred at cx,cy, size s, draw-on k) ----------
const ICON = {
  scissors(g, cx, cy, s, k, t) {
    for (const sg of [-1, 1]) {
      const rx = cx + sg * s * .28, ry = cy + s * .55;
      D.gline(g, D.arcPts(rx, ry, s * .17, 0, TAU, 40), { w: 4, part: k, closed: true, glow: .3 });
      D.gline(g, [[rx - sg * s * .05, ry - s * .16], [cx - sg * s * .32, cy - s * .75]], { w: 5, part: k, glow: .3 });
    }
    g.save(); g.globalAlpha *= ss(seg(k, .6, 1));
    D.drawShape(g, D.arcPts(cx, cy - s * .02, s * .05, 0, TAU, 16), {});
    // a drop of colour (the one colour) at the blade tips
    D.drawShape(g, [[cx + s * .55, cy - s * .55], [cx + s * .68, cy - s * .32], [cx + s * .55, cy - s * .22], [cx + s * .42, cy - s * .32]], { color: ROSE, lw: 2 });
    g.restore();
  },
  strands(g, cx, cy, s, k, t) {
    for (let i = 0; i < 7; i++) {
      const x0 = cx + (i - 3) * s * .1, pts = [];
      for (let j = 0; j <= 40; j++) { const u = j / 40; pts.push([x0 + Math.sin(u * 5 + i * .5 + t * 1.5) * s * .12 * u + (i - 3) * s * .06 * u, cy - s * .8 + u * s * 1.6]); }
      D.gline(g, pts, { w: i === 3 ? 4 : 2.6, part: clamp(k * 1.2 - i * .03), color: i === 3 ? ROSE : null, glow: .25 });
    }
    if (k > .03) D.gline(g, [[cx - s * .42, cy - s * .82], [cx + s * .42, cy - s * .82]], { w: 6, part: k, double: 8 });
  },
  lipstick(g, cx, cy, s, k, t) {
    const lx = cx - s * .28;
    D.gline(g, D.rectPts(lx - s * .14, cy, s * .28, s * .75), { w: 3.5, part: k, closed: true });
    D.chevrons(g, lx - s * .14, lx + s * .14, cy + s * .2, { n: 4, h: 12, rows: 2, gap: 12 });
    g.save(); g.globalAlpha *= ss(seg(k, .4, 1));
    D.drawShape(g, [[lx - s * .1, cy], [lx - s * .1, cy - s * .32], [lx + s * .1, cy - s * .48], [lx + s * .1, cy]], { color: ROSE, lw: 2.4 });
    g.restore();
    const mx = cx + s * .3, my = cy + s * .2;
    D.gline(g, D.arcPts(mx, my, s * .3, -Math.PI / 2, Math.PI * 1.5, 60), { w: 4, part: k, double: 9, glow: .3 });
    g.save(); g.globalAlpha *= .5 * ss(seg(k, .5, 1)); D.sunburst(g, mx, my, { rays: 24, r0: s * .05, r1: s * .24, w: 2 }); g.restore();
    D.sparkle(g, mx - s * .1, my - s * .12, s * .1 * ss(seg(k, .7, 1)), { rot: t });
  },
  tooth(g, cx, cy, s, k, t) {
    s *= .78; cy += s * .12;
    const P = [];
    const r = s * .55, top = cy - s * .55;
    // crown: two lobes, roots below
    for (let i = 0; i <= 20; i++) { const a = Math.PI + Math.PI * i / 20; P.push([cx - r * .45 + Math.cos(a) * r * .55, top + r * .5 + Math.sin(a) * r * .5]); }
    for (let i = 0; i <= 20; i++) { const a = Math.PI + Math.PI * i / 20; P.push([cx + r * .45 + Math.cos(a) * r * .55, top + r * .5 + Math.sin(a) * r * .5]); }
    P.push([cx + r * .95, cy + s * .1], [cx + r * .6, cy + s * .75], [cx + r * .2, cy + s * .2], [cx, cy + s * .12], [cx - r * .2, cy + s * .2], [cx - r * .6, cy + s * .75], [cx - r * .95, cy + s * .1]);
    g.save(); g.globalAlpha *= ss(seg(k, .55, 1));
    D.airbrush(g, P, { base: C.ivory, rim: 3, dir: -2.3 }); g.restore();
    D.gline(g, P, { w: 4, part: k, closed: true, glow: .35 });
    for (let i = 0; i < 3; i++) {
      const ph = (t * 1.3 + i / 3) % 1, a = ss(seg(k, .6, 1)) * Math.sin(ph * Math.PI);
      D.sparkle(g, cx + [-.75, .8, .1][i] * s, cy + [-.7, -.45, -.95][i] * s, s * (.12 + .06 * i) * a, { rot: ph });
    }
  },
  hourglass(g, cx, cy, s, k, t) {
    const L = [], R = [];
    for (let j = 0; j <= 40; j++) {
      const u = j / 40, y = cy - s * .85 + u * s * 1.7;
      const w = s * (.34 + .02 * Math.cos(u * TAU) - .2 * Math.exp(-Math.pow((u - .42) / .14, 2)) + .14 * Math.exp(-Math.pow((u - .72) / .16, 2)));
      L.push([cx - w, y]); R.push([cx + w, y]);
    }
    D.gline(g, L, { w: 4, part: k, glow: .35 }); D.gline(g, R, { w: 4, part: k, glow: .35 });
    g.save(); g.globalAlpha *= ss(seg(k, .5, 1));
    D.gline(g, [[cx - s * .3, cy - s * .12], [cx + s * .3, cy - s * .12]], { w: 2, color: ROSE });
    D.speedLines(g, cx - s * .55, cy - s * .12, Math.PI, { n: 3, len: s * .5, spread: s * .2, w: 4 });
    D.speedLines(g, cx + s * .55, cy - s * .12, 0, { n: 3, len: s * .5, spread: s * .2, w: 4, seed: 4 });
    g.restore();
  },
};

// ---------- scenes ----------
function sceneHook(g, t) {
  bg(g, EMER);
  particles(g, t, ss(seg(t, 1, 2.2)));
  const zoom = lerp(1.08, 1, eo(seg(t, 0, 4)));
  g.save(); g.translate(CX, 900); g.scale(zoom, zoom); g.translate(-CX, -900);
  const burst = eo(seg(t, .6, 1.8));
  D.sunburst(g, CX, 900, { rays: 64, r1: 1500 * burst, mode: 'wedges', rot: t * .03 });
  D.sunburst(g, CX, 900, { rays: 48, r0: 140, r1: 140 + 1100 * burst, mode: 'lines', alpha: .55, rot: t * .03, sheen: lerp(-.2, 1.2, seg(t, 1.2, 3)) });
  // the axis: a hairline draws up the centre
  const ax = eio(seg(t, 0, .8));
  D.gline(g, [[CX, H], [CX, H - (H - 100) * ax]], { w: 3, glow: 1 - burst * .7 });
  D.glow(g, CX, H - (H - 100) * ax, 120, '#ffcf7a', .5 * (1 - burst));
  // gem lands on the axis
  const gp = back(seg(t, .7, 1.3));
  if (gp > 0) gem(g, CX, 900, 120 * gp, t, { halo: burst });
  g.restore();
  T.titleBar(g, ED.open, CX, 1340, { p: seg(t, 1.2, 2.4), size: fitSize(ED.open, 92, 820, .8), sub: ED.openSub, subSize: 30, wings: ED.open.length < 14 });
  g.save(); g.globalAlpha *= ss(seg(t, 2.2, 2.8));
  T.goldText(g, ED.header, CX, 300, { size: 52, font: T.FONTS.deco, track: 14 });
  D.chevrons(g, CX - 200, CX + 200, 340, { n: 10, h: 14, rows: 2, gap: 10 });
  g.restore();
  frameBorder(g, ss(seg(t, 1.5, 2.5)));
}

function sceneService(g, t, i) {
  const S = SERVICES[i], lt = t - (SERV_T0 + SERV_LEN * i);
  bg(g, i % 2 ? JEWEL2 : EMER);
  const push = lerp(1, 1.05, ss(seg(lt, 0, SERV_LEN)));
  const tilt = (i % 2 ? -1 : 1) * lerp(18, -18, ss(seg(lt, 0, SERV_LEN)));
  g.save(); g.translate(CX, 1000); g.scale(push, push); g.translate(-CX, -1000 + tilt);
  D.sunburst(g, CX, 1380, { rays: 56, r1: 1700, mode: 'wedges', rot: lt * .02 });
  const k = eio(seg(lt, .15, 1.3));
  const inner = D.archFrame(g, CX, 1380, 880, 1020, { part: eio(seg(lt, 0, .9)), fill: '#0a0806', sheen: lerp(-.2, 1.2, seg(lt, .8, 2.2)) });
  g.save(); g.clip(D.toPath(inner, true));
  D.fishScale(g, 0, 1170, W, 220, 34, { stroke: 'rgba(201,162,75,.35)' });
  ICON[S.icon](g, CX, 820, 380, k, t);
  g.restore();
  g.restore();
  // dial carries the count
  const n = i + 1, dv = lerp(i / 5, n / 5, back(seg(lt, .1, .7)));
  T.dial(g, CX, 200, 100, dv, { labels: ['', '1', '2', '3', '4', '5', ''] });
  T.decoDigits(g, '0' + n, CX, 290, 40);
  T.titleBar(g, S.title, CX, 1500, { p: seg(lt, .35, 1.2), size: S.title.length > 13 ? 70 : 80, sub: S.sub });
  frameBorder(g);
}

function sceneBreath(g, t) {
  bg(g);
  const lt = t - BREATH[0];
  const pulse = 1 + .08 * Math.exp(-((lt % .5) * 8));
  gem(g, CX, 900, 90 * pulse, t, { halo: .3 });
}

const LINE1 = 'MAI STYLE', LINE2 = 'BEAUTY';
function sceneMarquee(g, t) {
  bg(g, JEWEL2);
  particles(g, t, .55);
  const lt = t - MARQ_T0;
  const s1 = B.buildSign(LINE1, { font: 'Limelight', size: 220, spacing: 19 }), s2 = B.buildSign(LINE2, { font: 'Limelight', size: 220, spacing: 19 });
  const sc = Math.min(900 / s1.w, 900 / s2.w);
  const times = []; const n1 = s1.letters.length, n2 = s2.letters.length;
  for (let i = 0; i < n1 + n2; i++) times.push(MARQ_T0 + .1 + i * MARQ_STEP);
  const lit = B.litSequence(t, times, { chaseFrom: MARQ_T0 + .1 + (n1 + n2) * MARQ_STEP + .2 });
  const lit2 = (li, bi, gi) => lit(li + n1, bi, gi + s1.count);
  // low oblique → centred: the sign card settles from a slight perspective
  const settle = eio(seg(lt, 0, 3.2));
  const allOn = seg(t, times[times.length - 1], times[times.length - 1] + .4);
  D.sunburst(g, CX, 700, { rays: 64, r1: 1600, mode: 'wedges', alpha: .4 + .6 * allOn });
  D.sunburst(g, CX, 700, { rays: 40, r0: 520, r1: 1400, mode: 'lines', alpha: .5 * allOn, sheen: lerp(-.2, 1.2, seg(t, 26, 27.5)) });
  D.glow(g, CX, 700, 700, '#ffc86a', .25 * allOn);
  g.save(); g.translate(CX, 700); g.transform(1, lerp(-.12, 0, settle), 0, 1, 0, 0); g.scale(lerp(.9, 1, settle), lerp(.9, 1, settle));
  const y1 = -s1.h * sc - 10, y2 = 10;
  B.drawSign(g, s1, -s1.w * sc / 2, y1, sc, { lit });
  B.drawSign(g, s2, -s2.w * sc / 2, y2, sc, { lit: lit2 });
  g.restore();
  // the gem crowns the sign
  const gp = back(seg(t, times[times.length - 1] + .1, times[times.length - 1] + .6));
  if (gp > 0) gem(g, CX, 300, 70 * gp, t, { halo: .6 });
  // CTA
  T.titleBar(g, ED.close, CX, 1290, { p: seg(t, CTA_T0, CTA_T0 + 1.2), size: fitSize(ED.close, 46, 820, .83), sub: 'HAIR · MAKEUP · SKIN · SMILE · BODY', subSize: 22, wings: false, pad: 30 });
  g.save(); g.globalAlpha *= ss(seg(t, CTA_T0 + 1, CTA_T0 + 1.8));
  T.goldText(g, ED.closeLine, CX, 1530, { size: Math.min(34, (940 - ED.closeLine.length * 12) / (ED.closeLine.length * .62)), font: T.FONTS.sans, weight: 600, track: 12, sheen: lerp(-.2, 1.2, seg(t, 28, 29.5)) });
  D.chevrons(g, CX - 160, CX + 160, 1570, { n: 8, h: 12, rows: 2, gap: 9 });
  g.restore();
  frameBorder(g, ss(seg(t, MARQ_T0, MARQ_T0 + 1)));
}

function drawScene(g, t) {
  if (t < SERV_T0) return sceneHook(g, t);
  if (t < BREATH[0]) return sceneService(g, t, Math.min(4, Math.floor((t - SERV_T0) / SERV_LEN)));
  if (t < BREATH[1]) return sceneBreath(g, t);
  return sceneMarquee(g, t);
}

// threshold doors: two lacquer leaves hinged at the frame edges, meeting on the centre seam
function doors(g, t) {
  let c = 0;
  for (const b of DOORS) {
    if (t >= b - .4 && t < b) c = Math.max(c, eio(seg(t, b - .4, b)));
    if (t >= b && t < b + .5) c = Math.max(c, 1 - eio(seg(t, b, b + .5)));
  }
  if (t >= BREATH[0] && t < BREATH[1]) c = 0;           // the breath sits behind open doors (dark room)
  if (c <= 0) return;
  const lw = CX * c;
  for (const sg of [-1, 1]) {
    const x0 = sg < 0 ? 0 : W - lw;
    g.save(); g.beginPath(); g.rect(x0, 0, lw, H); g.clip();
    const ox = sg < 0 ? lw - CX : W - lw;     // leaf slides with its content
    g.translate(ox, 0);
    D.airbrush(g, D.rectPts(0, 0, CX, H), { base: '#1a1310', dir: sg < 0 ? -2.3 : -.8, bbox: [0, 0, CX, H] });
    D.gline(g, D.rectPts(30, 60, CX - 60, H - 120), { w: 2.4, closed: true, double: 10 });
    D.sunburst(g, sg < 0 ? CX : 0, H / 2, { rays: 18, r0: 60, r1: 420, a0: sg < 0 ? Math.PI / 2 : -Math.PI / 2, a1: sg < 0 ? Math.PI * 1.5 : Math.PI / 2, w: 2 });
    D.chevrons(g, 60, CX - 60, 240, { n: 8, h: 18, rows: 3, gap: 10 });
    D.chevrons(g, 60, CX - 60, H - 300, { n: 8, h: 18, rows: 3, gap: 10 });
    g.restore();
  }
  D.gline(g, [[CX, 0], [CX, H]], { w: 2, glow: c });
}

export function render(g, t) {
  g.save(); drawScene(g, t); doors(g, t);
  D.vignette(g, W, H, .45);
  g.restore();
}
