# Mai Style Beauty — 30 s promo (Art Deco), 1080×1920, 24 fps

## Candidate structures
1. **The five doors** — a salon façade; each door splits on the centre seam to reveal one service; a dial at the top counts 1→5; the house name lights in bulbs.
2. **The vanity mirror** — one deco mirror whose frame changes per service; ends with the name lit around the mirror.
3. **The countdown to you** — a clock pushes from 5 to "now"; each tick a service.
**Chosen: 1 + the mirror finale.** Five services read cleanly as five doors; the dial carries the count without narration; the finale (bulb marquee) gives a strong, readable CTA for Reels.

## Logline / arc
A single rose-coloured gem (the client — "the one colour") travels through five gold doors of the House of Mai and comes out as the brightest thing on the marquee.
Setup (gold line + sunburst hook) → five services (doors) → beat of near-silence → marquee lights letter by letter → CTA.

## Benchmark
Learn: Cassandre posters' central axis and giant geometry; Gatsby-style title draw-on in gold; newsreel fanfare pacing.
Don't take: any poster layout, typeface design (we use OFL fonts), melody.

## Shots / beats (120 bpm, beat 0.5 s, bar 2 s)
| t (s) | shot | move | why |
|---|---|---|---|
| 0–3.5 | gold hairline draws up the axis, sunburst bursts, "YOUR GLOW-UP STARTS HERE" | push-in | hook in 3 s |
| 3.5–4.5 | door leaves split on the seam | split | threshold |
| 4.5–20.5 | five services × 3.2 s: arch frame, gold-drawn icon, title, dial 1–5 | slow push / tilt per door, door split between | dials carry plot |
| 20.5–22 | everything dims, one clock tick | near-silence | breath before peak |
| 22–27 | marquee "MAI STYLE BEAUTY" lights one letter per beat | low oblique → centre | counted light (signature) |
| 27–30 | "BOOK YOUR APPOINTMENT" plaque unfolds from centre; sheen sweep | hold | CTA ≥ 3 s |

## Sound
Synthesised foxtrot at 120 bpm: stride piano chords, walking bass, brush snare, bell on each door/bulb, relay "chunk" per bulb, cymbal swell on the finale. Near-silence at 20.5 s with a clock tick. No narration (Reels are watched muted) — all text on screen.

## Type
Limelight titles, Poiret One numerals/dial, Josefin Sans labels. Accent rose #C8506A, jewel emerald #1F5A4A, gold.
