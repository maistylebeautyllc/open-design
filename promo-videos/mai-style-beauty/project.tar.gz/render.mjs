// node render.mjs stills 1.5 6 ...   |  node render.mjs video out/video.mp4
import http from 'node:http'; import fs from 'node:fs'; import path from 'node:path'; import { spawn } from 'node:child_process';
import pw from '/opt/node-tools/node_modules/playwright/index.js'; const { chromium } = pw;
const root = path.dirname(new URL(import.meta.url).pathname);
const types = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.ttf': 'font/ttf' };
const srv = http.createServer((q, r) => { const f = path.join(root, decodeURIComponent(q.url.split('?')[0])); fs.readFile(f, (e, d) => { if (e) { r.writeHead(404); r.end(); return; } r.writeHead(200, { 'content-type': types[path.extname(f)] || 'application/octet-stream' }); r.end(d); }); }).listen(0);
const port = srv.address().port;
const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 1080, height: 1920 } });
p.on('pageerror', e => console.error('PAGE', e.message));
await p.goto(`http://127.0.0.1:${port}/index.html?ed=${process.env.ED || 'main'}`); await p.waitForFunction(() => window.ready, null, { timeout: 30000 });
const shot = async t => { const u = await p.evaluate(t => { window.renderAt(t); return document.getElementById('c').toDataURL('image/jpeg', .93); }, t); return Buffer.from(u.split(',')[1], 'base64'); };
const [mode, ...args] = process.argv.slice(2);
if (mode === 'stills') { fs.mkdirSync(path.join(root, 'out/stills'), { recursive: true }); for (const a of args) fs.writeFileSync(path.join(root, `out/stills/s_${a}.jpg`), await shot(+a)); }
else {
  const fps = 24, N = 30 * fps;
  const ff = spawn('ffmpeg', ['-y', '-loglevel', 'error', '-f', 'image2pipe', '-framerate', String(fps), '-c:v', 'mjpeg', '-i', '-', '-c:v', 'libx264', '-pix_fmt', 'yuv420p', '-crf', '17', '-preset', 'medium', args[0]], { stdio: ['pipe', 'inherit', 'inherit'] });
  for (let i = 0; i < N; i++) { const buf = await shot(i / fps); if (!ff.stdin.write(buf)) await new Promise(r => ff.stdin.once('drain', r)); if (i % 120 === 0) console.log('frame', i); }
  ff.stdin.end(); await new Promise(r => ff.on('close', r));
}
await b.close(); srv.close();
