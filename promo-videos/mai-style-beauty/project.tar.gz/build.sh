#!/bin/sh
# Rebuild the Mai Style Beauty promo from scratch (needs node + playwright chromium, python3 + numpy, ffmpeg).
set -e; cd "$(dirname "$0")"
python3 score.py                                   # original score + foley → out/score.wav
node render.mjs video out/video.mp4                # 720 frames, 1080×1920 @ 24 fps
ffmpeg -y -loglevel error -i out/video.mp4 -i out/score.wav -filter_complex "[1:a]loudnorm=I=-14:TP=-1.5:LRA=11[a]" -map 0:v -map "[a]" -c:v copy -c:a aac -b:a 192k -ar 48000 -shortest mai-style-beauty-promo.mp4
ffmpeg -y -loglevel error -ss 27.5 -i mai-style-beauty-promo.mp4 -frames:v 1 -q:v 2 poster.jpg
