#!/bin/sh
# Build the holiday editions: sh build_holidays.sh thanksgiving blackfriday hmong
set -e; cd "$(dirname "$0")"
[ -f out/score.wav ] || python3 score.py
for e in "$@"; do
  ED=$e node render.mjs video out/video_$e.mp4
  ffmpeg -y -loglevel error -i out/video_$e.mp4 -i out/score.wav -filter_complex "[1:a]loudnorm=I=-14:TP=-1.5:LRA=11[a]" -map 0:v -map "[a]" -c:v copy -c:a aac -b:a 192k -ar 48000 -shortest mai-style-beauty-$e.mp4
  ffmpeg -y -loglevel error -ss 2.8 -i mai-style-beauty-$e.mp4 -frames:v 1 -q:v 2 poster-$e.jpg
done
