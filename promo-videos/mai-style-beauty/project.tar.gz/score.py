# Original score + foley for the Mai Style Beauty promo. Pure numpy synthesis → out/score.wav (48 kHz stereo).
import numpy as np, wave, os
SR = 48000; DUR = 30.0; BEAT = 0.5
N = int(SR * DUR); L = np.zeros(N); R = np.zeros(N)
rng = np.random.default_rng(7)
mf = lambda m: 440.0 * 2 ** ((m - 69) / 12)

def put(sig, t, pan=0.0, g=1.0):
    i = int(t * SR); j = min(N, i + len(sig))
    if j <= i: return
    s = sig[:j - i] * g
    L[i:j] += s * np.sqrt(0.5 * (1 - pan)); R[i:j] += s * np.sqrt(0.5 * (1 + pan))

def tt(d): return np.arange(int(d * SR)) / SR
def lowpass(x, a):  # one-pole
    y = np.empty_like(x); acc = 0.0
    for i in range(len(x)): acc += a * (x[i] - acc); y[i] = acc
    return y
def hp(x): return np.diff(x, prepend=0.0)

def piano(m, d=1.2, v=1.0):
    t = tt(d + .3); f = mf(m); s = np.zeros_like(t)
    for h, a in [(1, 1), (2, .5), (3, .25), (4, .12), (5, .06)]:
        s += a * np.sin(2 * np.pi * f * h * t * (1 + .0004 * h)) * np.exp(-t * (2.2 + h * .9))
    env = np.minimum(1, t / .004); rel = np.clip((d + .3 - t) / .3, 0, 1)
    return s * env * rel * v * .22
def bass(m, d=.48, v=1.0):
    t = tt(d); f = mf(m)
    s = np.sin(2 * np.pi * f * t) + .35 * np.sin(4 * np.pi * f * t)
    return s * np.exp(-t * 5) * np.minimum(1, t / .006) * v * .35
def clarinet(m, d, v=1.0):
    t = tt(d); f = mf(m) * (1 + .004 * np.sin(2 * np.pi * 5.2 * t) * np.clip(t / .4, 0, 1))
    ph = 2 * np.pi * np.cumsum(f) / SR
    s = np.sin(ph) + .45 * np.sin(3 * ph) + .2 * np.sin(5 * ph) + .08 * np.sin(7 * ph)
    env = np.clip(t / .04, 0, 1) * np.clip((d - t) / .08, 0, 1)
    return s * env * v * .09
def bell(m, d=2.2, v=1.0):
    t = tt(d); f = mf(m); s = np.zeros_like(t)
    for r, a, k in [(1, 1, 1.6), (2.76, .5, 2.6), (5.4, .25, 4), (8.93, .12, 6)]:
        s += a * np.sin(2 * np.pi * f * r * t) * np.exp(-t * k)
    return s * np.minimum(1, t / .002) * v * .16
def xylo(m, v=1.0):
    t = tt(.5); f = mf(m)
    return (np.sin(2 * np.pi * f * t) + .3 * np.sin(2 * np.pi * f * 4 * t) * np.exp(-t * 40)) * np.exp(-t * 9) * v * .2
def noise(d): return rng.standard_normal(int(d * SR))
def brush(v=1.0, d=.22):
    t = tt(d); return hp(noise(d)) * np.exp(-t * 18) * v * .05
def swish(d=.45, v=1.0):
    t = tt(d); return lowpass(noise(d), .25) * np.sin(np.pi * t / d) ** 2 * v * .06
def cymbal(d=2.0, v=1.0, swell=False):
    t = tt(d); x = hp(hp(noise(d)))
    env = (t / d) ** 2 if swell else np.exp(-t * 2.2)
    return x * env * v * .05
def timp(m, v=1.0):
    t = tt(1.2); f = mf(m) * (1 + .03 * np.exp(-t * 20))
    return np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t * 3) * v * .5
def chunk(v=1.0):  # relay / knife-switch
    t = tt(.15); return (np.sin(2 * np.pi * 70 * t) * np.exp(-t * 40) + hp(noise(.15)) * np.exp(-t * 90) * .5) * v * .45
def tick(v=1.0):
    t = tt(.06); return hp(noise(.06)) * np.exp(-t * 160) * v * .7 + np.sin(2 * np.pi * 2400 * t) * np.exp(-t * 120) * v * .15
def whoosh(d=.45, v=1.0):
    t = tt(d); x = lowpass(noise(d), .08) * np.sin(np.pi * t / d) ** 1.5
    return x * v * .5

# harmony: F6 | D7 | Gm7 | C7  (one chord per bar = 2 s)
CH = [(53, [57, 60, 62, 65]), (50, [54, 57, 60, 62]), (55, [58, 62, 65, 67]), (48, [52, 55, 58, 60])]
WALK = {0: [53, 57, 60, 62], 1: [50, 54, 57, 60], 2: [55, 58, 62, 61], 3: [48, 52, 55, 52]}

def band(t0, t1, mel=True, v=1.0):
    b = int(round(t0 / BEAT))
    while b * BEAT < t1 - 1e-6:
        t = b * BEAT; bar = (b // 4) % 4; beat = b % 4
        root, chord = CH[bar]
        put(bass(WALK[bar][beat] - 12, v=v), t, -.1)
        if beat in (0, 2): put(piano(root - 12 if beat == 0 else root - 5, .45, v), t, -.3)
        else: [put(piano(n, .35, .55 * v), t, -.2) for n in chord]
        if beat in (1, 3): put(brush(v), t, .3)
        put(swish(.45, .6 * v), t + .05, .35)
        if mel and beat == 0:
            # Charleston rhythm on chord tones (dotted quarter + eighth tied ...), phrase varies by bar
            hi = [c + 12 for c in chord]; seq = [(0, .75, hi[3]), (.75, .75, hi[2]), (1.5, .5, hi[1]), (2, 1.5, hi[(bar + 2) % 4])] if bar % 2 == 0 else \
                  [(0, .5, hi[0]), (.5, .5, hi[1]), (1, .5, hi[2]), (1.5, 2, hi[3] + (2 if bar == 3 else 0))]
            for sb, d, m in seq:
                if t + sb * BEAT < t1: put(clarinet(m, min(d * BEAT, t1 - t - sb * BEAT) * .95, v), t + sb * BEAT, .2)
        b += 1

# --- 0–4 s: hook. harp gliss with the axis, hit on the burst, band enters at 2.0
for i, m in enumerate(range(53, 89, 2)): put(xylo(m, .5) * .7, .05 + i * .045, -.4 + i * .04)
put(cymbal(1.0, .8, swell=True), 0.0, 0)
put(timp(41, .9), 1.0); [put(bell(m, 2.0, .6), 1.0, .2) for m in (77, 81, 84)]; put(cymbal(2.0, 1), 1.0)
band(2.0, 21.5)
# --- doors: whoosh as leaves close, chunk + bell as they meet
DOORS = [4.0, 7.5, 11.0, 14.5, 18.0, 21.5]
for i, d in enumerate(DOORS):
    put(whoosh(.45, .8), d - .42, -.2 if i % 2 else .2)
    put(chunk(.8), d, 0)
    if d < 21.5: put(bell([72, 74, 76, 77, 79][i], 2.0, .9), d, 0)
# --- breath: hush, one clock tick per beat
for t in (21.5, 22.0): put(tick(1.0), t, 0)
# --- marquee: one bulb per eighth, xylophone climbing, band back on the last letter
letters = 14
for i in range(letters):
    t = 22.6 + i * .25
    put(chunk(.35), t, -.5 + i / letters); put(xylo([65, 67, 69, 70, 72, 74, 76, 77, 79, 81, 82, 84, 86, 89][i], .9), t, -.5 + i / letters)
put(cymbal(1.6, .9, swell=True), 24.3)
put(timp(41, 1.0), 26.0); [put(bell(m, 2.5, .7), 26.0, 0) for m in (77, 81, 84, 89)]; put(cymbal(2.5, 1.1), 26.0)
band(26.0, 29.0, v=1.05)
# final chord
for n in (41, 53, 57, 60, 62, 65, 69): put(piano(n, 1.2, .9), 29.0, 0)
put(clarinet(77, .9, 1.0), 29.0, .2); put(timp(41, .8), 29.0); put(cymbal(1.0, .8), 29.0)

mx = np.max(np.abs(np.concatenate([L, R]))); L /= mx / .9; R /= mx / .9
fade = np.clip((DUR - np.arange(N) / SR) / .25, 0, 1); L *= fade; R *= fade
os.makedirs('out', exist_ok=True)
with wave.open('out/score.wav', 'wb') as w:
    w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR)
    w.writeframes((np.stack([L, R], 1) * 32767).astype('<i2').tobytes())
print('ok')
